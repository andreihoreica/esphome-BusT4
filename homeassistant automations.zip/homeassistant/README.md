# Home Assistant – automatizări poartă Nice / gate automations

🇷🇴 [Română](#română) · 🇬🇧 [English](#english)

---

## Română

Automatizările Home Assistant care folosesc placa ESPHome BusT4 (Nice Robus 600) din acest repo.
Sunt exemple anonimizate: numele persoanelor, telefoanele, orele de blocare și distanțele trebuie
adaptate instalației voastre.

### Conținut

| Fișier | Rol |
|---|---|
| `automations/poarta_nice_v10_gestionare.yaml` | Deschidere automată la apropiere (zonă, distanță, intrare acasă, pe jos), închidere, blocare noaptea / când toți sunt departe |
| `automations/poarta_nice_fallback_notificare.yaml` | Notificare cu butoane dacă poarta nu s-a deschis singură |
| `automations/poarta_nice_watchdog_inchidere.yaml` | Reîncearcă închiderea dacă poarta rămâne deschisă după o deschidere automată |
| `automations/poarta_nice_verificare_dupa_restart.yaml` | După restartul HA: verifică placa, L1/L2, poarta deschisă, starea de blocare |
| `automations/poarta_nice_asigura_l1_l2.yaml` | Pornește L1/L2 dacă poarta e deschisă din telecomandă cu ele oprite |
| `scripts/poarta_asigura_stare_blocare.yaml` | Lock/unlock cu verificare și reîncercări (folosit de V10 și de verificarea după restart) |
| `packages/poarta_bayesian.yaml` | Senzori Bayesian „Mașină se apropie de poartă” (folosiți de fallback) |

### Entități necesare

**De la placa ESP (nice.yaml):** `cover.poarta_nice_poarta_nice`, `lock.nice_gate_securitate_poarta`,
`button.nice_gate_deblocheaza_si_deschide`, `button.nice_gate_deblocheaza_si_inchide`,
`button.nice_gate_deschide_si_blocheaza`, `switch.nice_gate_inchidere_automata_l1`,
`switch.nice_gate_inchidere_dupa_foto_l2`, `sensor.nice_gate_procentaj_deschidere_poarta`.

**De adaptat la instalația voastră** (înlocuiți peste tot):

| În fișiere | Ce este |
|---|---|
| `person.persoana1`, `person.persoana2` | Persoanele din HA |
| `device_tracker.telefon1`, `device_tracker.telefon2` | Telefoanele (Companion App) |
| `sensor.telefon1_activity`, `sensor.telefon2_activity` | Senzorul de activitate iOS (Automotive / Walking) |
| `sensor.persoana1_distance`, `sensor.persoana2_distance` | Distanța față de casă (integrarea Proximity) |
| `sensor.home_persoana1_direction_of_travel`, `..._persoana2_...` | Direcția de deplasare (Proximity) |
| `notify.mobile_app_telefon1`, `notify.mobile_app_telefon2` | Serviciile de notificare ale telefoanelor |
| `zone.apropiere_poarta` | Zonă pasivă în jurul porții (aici 290 m) |
| `input_boolean.acces_poarta_prieten` | Helper: acces pentru un prieten (nu blochează poarta când sunteți plecați) |

**Valori de exemplu:** blocare 22:30, deblocare 06:30 (L-V) / 08:00 (S-D), reblocare după trecere
23:00–06:30, „toți departe” peste 20 km, revenire sub 15 km. Dacă le schimbați în V10, schimbați-le
și în `poarta_nice_verificare_dupa_restart.yaml` (variabila `noapte` e în minute: 1350 = 22:30,
390 = 06:30, 480 = 08:00) și în reblocarea din fallback și watchdog.

### Instalare

1. Creați helperul `input_boolean.acces_poarta_prieten` și zona `zone.apropiere_poarta` (pasivă).
2. Copiați `packages/poarta_bayesian.yaml` în `config/packages/` (cu `homeassistant: packages: !include_dir_named packages`).
3. Scriptul: **Setări → Automatizări și scene → Scripturi → Script nou → ⋮ → Editează în YAML**,
   lipiți conținutul și salvați cu ID-ul `poarta_asigura_stare_blocare`.
4. Fiecare automatizare: **Automatizare nouă → ⋮ → Editează în YAML**, lipiți conținutul fișierului, salvați.
   Ordinea recomandată: V10 primul, pentru că watchdog-ul și „Asigură L1/L2” îl referă ca
   `automation.poarta_nice_gestionare_inteligenta_v10` (ID-ul generat din titlu). Dacă ID-ul vostru
   diferă, corectați-l în cele două fișiere.

   Alternativ, în `configuration.yaml`: `automation poarta: !include_dir_list automations/`
   (fiecare fișier conține o singură automatizare).

### Observații

- L1 = închidere automată după pauză; L2 = închidere imediat după eliberarea fotocelulelor.
  V10 le oprește intenționat cât ține poarta deschisă 90 s (Open&Block) și le repornește după.
- Nicio automatizare de aici nu deschide poarta după un restart.
- În script, așteptarea stării folosește `wait_template` (versiunea inițială folosea un șablon în
  câmpul `to` al unui `wait_for_trigger`, pe care HA nu îl evaluează).

---

## English

The Home Assistant automations that use the ESPHome BusT4 board (Nice Robus 600) in this repo.
They are anonymised examples: person names, phones, lock times and distances must be adapted to
your installation. Entity IDs and messages are in Romanian, as in the original installation.

### Contents

| File | Purpose |
|---|---|
| `automations/poarta_nice_v10_gestionare.yaml` | Automatic opening on approach (zone, distance, arriving home, on foot), closing, night lock / lock when everybody is away |
| `automations/poarta_nice_fallback_notificare.yaml` | Actionable notification if the gate did not open by itself |
| `automations/poarta_nice_watchdog_inchidere.yaml` | Retries closing if the gate stays open after an automatic opening |
| `automations/poarta_nice_verificare_dupa_restart.yaml` | After an HA restart: checks the board, L1/L2, a gate left open, lock state |
| `automations/poarta_nice_asigura_l1_l2.yaml` | Turns L1/L2 on if the gate is opened by remote while they are off |
| `scripts/poarta_asigura_stare_blocare.yaml` | Lock/unlock with verification and retries (used by V10 and the restart check) |
| `packages/poarta_bayesian.yaml` | Bayesian "car approaching the gate" sensors (used by the fallback) |

### Required entities

**From the ESP board (nice.yaml):** `cover.poarta_nice_poarta_nice`, `lock.nice_gate_securitate_poarta`,
`button.nice_gate_deblocheaza_si_deschide` (unlock & open), `button.nice_gate_deblocheaza_si_inchide`
(unlock & close), `button.nice_gate_deschide_si_blocheaza` (open & block),
`switch.nice_gate_inchidere_automata_l1`, `switch.nice_gate_inchidere_dupa_foto_l2`,
`sensor.nice_gate_procentaj_deschidere_poarta` (opening %).

**To adapt** (replace everywhere): `person.persoana1/2` (people), `device_tracker.telefon1/2`
(phones), `sensor.telefon1/2_activity` (iOS activity), `sensor.persoana1/2_distance` and
`sensor.home_persoana1/2_direction_of_travel` (Proximity integration), `notify.mobile_app_telefon1/2`,
`zone.apropiere_poarta` (passive zone around the gate, 290 m here), `input_boolean.acces_poarta_prieten`
(friend access helper: the gate is not locked while you are away).

**Example values:** lock 22:30, unlock 06:30 (Mon–Fri) / 08:00 (Sat–Sun), relock after passing
23:00–06:30, "everybody away" above 20 km, return below 15 km. If you change them in V10, change
them in the restart check as well (`noapte` is in minutes: 1350 = 22:30, 390 = 06:30, 480 = 08:00)
and in the relock step of the fallback and the watchdog.

### Installation

1. Create the `input_boolean.acces_poarta_prieten` helper and the passive `zone.apropiere_poarta`.
2. Copy `packages/poarta_bayesian.yaml` to `config/packages/`.
3. Script: **Settings → Automations & scenes → Scripts → New script → ⋮ → Edit in YAML**, paste,
   save with the ID `poarta_asigura_stare_blocare`.
4. Each automation: **New automation → ⋮ → Edit in YAML**, paste the file content, save. Create V10
   first: the watchdog and "Asigură L1/L2" refer to it as `automation.poarta_nice_gestionare_inteligenta_v10`.
   Alternatively: `automation poarta: !include_dir_list automations/` in `configuration.yaml`.

### Notes

- L1 = auto-close after the pause; L2 = close right after the photocells are cleared. V10 turns them
  off on purpose while it holds the gate open for 90 s (Open&Block) and turns them back on afterwards.
- None of these automations opens the gate after a restart.
